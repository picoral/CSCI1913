
def selection_sort(lst):
    """Sort the list lst in-place"""
    count = 0
    for i in range(len(lst) - 1):
        # Find index of smallest remaining element
        index_smallest = i
        for j in range(i + 1, len(lst)):
            count += 1
            if lst[j] < lst[index_smallest]:
                index_smallest = j

        # Swap lst[i] and lst[index_smallest]
        lst[i], lst[index_smallest] = lst[index_smallest], lst[i]
    return count


def insertion_sort(lst):
    """Sort the list lst in-place"""
    count = 0
    for i in range(1, len(lst)):
        j = i
        # insert lst[i] into sorted part
        # stopping once lst[i] in correct position

        # KLUVER NOTE - PLEASE READ - so this line is a bit tricky.
        #               Technically, if j > 0 then lst would not
        #               be compared to make things easier you can
        #               assume that every time the list condition is
        #               checked one array element comparison occurs.
        #               That is -- you can ignore the short-circuit
        #               evaluation of the logical and in this counting
        #               problem.
        count += 1
        while j > 0 and lst[j] < lst[j - 1]:
            count += 1
            # swap lst[j] and lst[j - 1]
            lst[j], lst[j-1] = lst[j-1], lst[j]
            j -= 1
    return count


def merge(lst, i, j, k):
    """Given two sorted sub-lists create one sorted list.

    This is done in-place, meaning we are given one list and expected to
    modify the list to be sorted.  Furthermore, this operates on
    "sub-lists" (a specific range of the list) The list named lst
    may contain other types of data than just numbers. The variables i,
    j, and k are all indices into the lst list so the part of the
    list to be sorted is from position i to k (inclusive) with i to j
    being one sorted list, and j+1 to k being another.
    """
    count = 0
    merged_size = k - i + 1  #  Size of merged partition
    merged_lst = []  #  Temporary list for merged lst
    for _ in range(merged_size):
        merged_lst.append(0)

    merge_pos = 0  #  Position to insert merged lst

    left_pos = i  #  Initialize left partition position
    right_pos = j + 1  #  Initialize right partition position

    #  Add smallest element from left or right partition to merged lst
    while left_pos <= j and right_pos <= k:
        count += 1
        if lst[left_pos] < lst[right_pos]:
            merged_lst[merge_pos] = lst[left_pos]
            left_pos = left_pos + 1
        else:
            merged_lst[merge_pos] = lst[right_pos]
            right_pos = right_pos + 1
        merge_pos = merge_pos + 1

    #  If left partition is not empty, add remaining elements to merged lst
    while left_pos <= j:
        merged_lst[merge_pos] = lst[left_pos]
        left_pos = left_pos + 1
        merge_pos = merge_pos + 1

    #  If right partition is not empty, add remaining elements to merged lst
    while right_pos <= k:
        merged_lst[merge_pos] = lst[right_pos]
        right_pos = right_pos + 1
        merge_pos = merge_pos + 1

    #  Copy merge lst back to lst
    merge_pos = 0
    while merge_pos < merged_size:
        lst[i + merge_pos] = merged_lst[merge_pos]
        merge_pos = merge_pos + 1
    return count


def merge_sort_recursive(lst, i, k):
    """Sort the sub-list in lst from position i to k (inclusive)"""
    count = 0
    if i < k:
        j = (i + k) // 2  #  Find the midpoint in the partition

        #  Recursively sort left and right partitions
        # KLUVER NOTE - PLEASE READ - you should think about these two function calls as returning a count of
        #     comparisons. Naturally the comparisons done by those function-calls will count against this function-call.
        #     make sure you're not ignoring the return values on the following two lines.
        count += merge_sort_recursive(lst, i, j)
        count += merge_sort_recursive(lst, j + 1, k)

        #  Merge left and right partition in sorted order
        count += merge(lst, i, j, k)
    return count

def merge_sort(lst):
    """Sort a list (lst)

    This function is added on-top of the textbook's code to simply start the recursive process with the
    appropriate parameters. This also gives us a consistent sorting interface over the three sorts.
    """
    return merge_sort_recursive(lst, 0, len(lst) - 1)

def bubble_sort(lst):
    count = 0
    n = len(lst)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            count += 1
            if lst[j] > lst[j + 1]:
                lst[j], lst[j + 1] = lst[j + 1], lst[j]
                swapped = True
        if not swapped:
            return count
    return count

def other_sort(lst):
    count = 0
    return count



