'''
Authors: Daniel Kluver (2020), Adriana Picoral (modified October 2026)
Description: Tool for plotting sort algorithm iteration counts
'''

import random
import polars as pl

from sorts import *
from plotnine import ggplot, aes, geom_point, facet_wrap, labs
from plotnine.data import mpg


LIST_TYPES = ["sorted_list", "near_sorted", "random", "backwards"]

def create_csv_files():
    for list_type in LIST_TYPES:
            out_csv = open(list_type + ".csv", "w")
            print("working on " + list_type + ".csv")
            print(
                "length", "selection", "insertion", "bubble", "merge", "other", sep=",", file=out_csv
            )
            for length in range(10, 1250, 15):
                lst = list(range(length))
                if list_type == "near_sorted":
                    for i in range(length):
                        a = random.randrange(length - 1)
                        lst[a], lst[a + 1] = lst[a + 1], lst[a]
                elif list_type == "random":
                    random.shuffle(lst)
                elif list_type == "backwards":
                    lst = lst[::-1]
                selection = selection_sort(lst[:])
                insertion = insertion_sort(lst[:])
                bubble = bubble_sort(lst[:])
                merge = merge_sort(lst[:])
                other = other_sort(lst[:])
                print(length, selection, insertion, bubble, merge, other, sep=",", file=out_csv)
                
    
            out_csv.close()
            print("done")

def plot_from_files():
     for list_type in LIST_TYPES:
          # open csv file
          df = pl.read_csv(list_type + ".csv")
          # pivot long
          df = df.unpivot(
            on=["selection", "insertion", "bubble", "merge", "other"],   # Columns to turn into rows
            index=["length"],                                            # Columns to keep as identifiers
            variable_name="sorting",                    
            value_name="iterations"                     
          )
 
          # scatter plot
          p = (
                ggplot(df, aes(x="length", y="iterations"))
                + geom_point()
                + facet_wrap("sorting")  # Splits data by the 'class' column
                + labs(x="length of list",
                       y="Number of Iterations",
                       title=list_type)
          )

          p.show()


if __name__ == "__main__":
     create_csv_files()
     plot_from_files()
    

   
    

        
