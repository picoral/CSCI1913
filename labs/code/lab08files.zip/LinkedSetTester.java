/**
 * LinkedSetTester class file.
 * CSCI 1913 -- Lab 08.
 * Written by Adriana Picoral in Fall 2026
 *
 * Run this file's main method to test your LinkedSet.
 * These are the same set behavior tests as ArraySetTester, plus a few linked-list edge cases.
 */

public class LinkedSetTester {
    public static void main(String[] args) {
        int errors = 0;

        System.out.println("***** Test empty set *****");
        Set<String> s = new LinkedSet<>();
        errors += Tester.doTest(0, s.size(), "size() of new set");
        errors += Tester.doTest(true, s.isEmpty(), "isEmpty() of new set");
        errors += Tester.doTest("{}", s.toString(), "toString() of new set");
        errors += Tester.doTest(false, s.contains("cat"), "contains(\"cat\") on new set");

        System.out.println("***** Test add *****");
        errors += Tester.doTest(true, s.add("cat"), "add(\"cat\") on empty set");
        errors += Tester.doTest(1, s.size(), "size() after 1 add");
        errors += Tester.doTest(false, s.isEmpty(), "isEmpty() after 1 add");
        errors += Tester.doTest(true, s.add("dog"), "add(\"dog\")");
        errors += Tester.doTest(false, s.add("cat"), "add(\"cat\") when cat already in set");
        errors += Tester.doTest(false, s.add("dog"), "add(\"dog\") when dog already in set");
        errors += Tester.doTest(2, s.size(), "size() after adding cat, dog, cat, dog");

        System.out.println("***** Test toString *****");
        s = new LinkedSet<>();
        s.add("a");
        errors += Tester.doTest("{a}", s.toString(), "toString() with one item");
        s.add("b");
        s.add("c");
        s.add("a");
        errors += Tester.doTest("{a, b, c}", s.toString(), "toString() after adding a, b, c, a");
        Set<Integer> nums = new LinkedSet<>();
        nums.add(3);
        nums.add(1);
        nums.add(2);
        errors += Tester.doTest("{3, 1, 2}", nums.toString(), "toString() of Set<Integer> after adding 3, 1, 2");

        System.out.println("***** Test contains uses .equals() *****");
        s = new LinkedSet<>();
        s.add(new String("cat"));
        errors += Tester.doTest(true, s.contains(new String("cat")), "contains() with a different String object holding \"cat\"");
        errors += Tester.doTest(false, s.contains("Cat"), "contains(\"Cat\")");
        errors += Tester.doTest(false, s.add(new String("cat")), "add() a different String object holding \"cat\"");
        nums = new LinkedSet<>();
        nums.add(1000);
        errors += Tester.doTest(true, nums.contains(Integer.valueOf(1000)), "contains(1000) using a different Integer object");

        System.out.println("***** Test remove *****");
        s = new LinkedSet<>();
        s.add("a");
        s.add("b");
        s.add("c");
        s.add("d");
        errors += Tester.doTest(false, s.remove("z"), "remove(\"z\") when z not in set");
        errors += Tester.doTest(true, s.remove("b"), "remove(\"b\") from the middle");
        errors += Tester.doTest(3, s.size(), "size() after remove(\"b\")");
        errors += Tester.doTest(false, s.contains("b"), "contains(\"b\") after remove");
        errors += Tester.doTest("{a, c, d}", s.toString(), "toString() after remove(\"b\")");
        errors += Tester.doTest(true, s.remove("a"), "remove(\"a\") (first item)");
        errors += Tester.doTest("{c, d}", s.toString(), "toString() after removing first item");
        errors += Tester.doTest(true, s.remove("d"), "remove(\"d\") (last item)");
        errors += Tester.doTest("{c}", s.toString(), "toString() after removing last item");
        s.add("e");
        errors += Tester.doTest("{c, e}", s.toString(), "toString() after add(\"e\")");
        s.remove("c");
        s.remove("e");
        errors += Tester.doTest("{}", s.toString(), "toString() after removing every item");
        errors += Tester.doTest(true, s.isEmpty(), "isEmpty() after removing every item");
        s.add("x");
        errors += Tester.doTest("{x}", s.toString(), "toString() after re-adding");

        System.out.println("***** Test clear *****");
        s = new LinkedSet<>();
        s.add("a");
        s.add("b");
        s.clear();
        errors += Tester.doTest(0, s.size(), "size() after clear()");
        errors += Tester.doTest("{}", s.toString(), "toString() after clear()");
        errors += Tester.doTest(false, s.contains("a"), "contains(\"a\") after clear()");
        s.add("d");
        errors += Tester.doTest("{d}", s.toString(), "toString() after clear() and add(\"d\")");

        System.out.println("***** Test head and tail edge cases *****");
        nums = new LinkedSet<>();
        for (int i = 0; i < 5; i++) {
            nums.add(i);
        }
        for (int i = 4; i >= 0; i--) {
            nums.remove(i);
        }
        errors += Tester.doTest("{}", nums.toString(), "toString() after removing every item from the end");
        nums.add(7);
        nums.add(8);
        errors += Tester.doTest("{7, 8}", nums.toString(), "toString() after re-adding 7, 8 (is tail correct?)");
        nums.remove(7);
        errors += Tester.doTest("{8}", nums.toString(), "toString() after removing the head");
        nums.remove(8);
        nums.add(9);
        errors += Tester.doTest("{9}", nums.toString(), "toString() after removing the only item and adding 9");
        s = new LinkedSet<>();
        s.add("c");
        s.add("d");
        s.add("a");
        s.remove("d");
        s.add("e");
        errors += Tester.doTest("{c, a, e}", s.toString(), "toString() after add c, d, a, remove d, add e");

        System.out.println("***** Test many items *****");
        nums = new LinkedSet<>();
        for (int i = 0; i < 1000; i++) {
            nums.add(i);
            nums.add(i);
        }
        errors += Tester.doTest(1000, nums.size(), "size() after adding 0..999 twice");
        for (int i = 0; i < 1000; i += 2) {
            nums.remove(i);
        }
        errors += Tester.doTest(500, nums.size(), "size() after removing even numbers");
        errors += Tester.doTest(false, nums.contains(500), "contains(500) after removing even numbers");
        errors += Tester.doTest(true, nums.contains(501), "contains(501) after removing even numbers");

        System.out.println();
        if (errors == 0) {
            System.out.println("All LinkedSet tests passed!");
        } else {
            System.out.println(errors + " LinkedSet test(s) failed.");
        }
    }
}
