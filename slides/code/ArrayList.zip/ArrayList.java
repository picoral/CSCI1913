public class ArrayList<T> implements List<T> {
    private T[] data;
    private int capacity = 10;
    private int length = 0;

    @SuppressWarnings("unchecked")
    public ArrayList() {
        data = (T[]) new Object[capacity];
    }

    @Override
    public int length() {
        return length;
    }

    @Override
    public void append(T value) {
        if (length == capacity) expandArray();
        data[length] = value;
        length++;
    }

    @SuppressWarnings("unchecked")
    private void expandArray() {
        capacity *= 2;
        T[] newData = (T[]) new Object[capacity];
        for (int i = 0; i < length; i++) newData[i] = data[i];
        data = newData;
    }

    @Override
    public T get(int index) {
        if (index < 0 || index >= length) throw new IndexOutOfBoundsException("index out of range");
        return data[index];
    }

    @Override
    public void set(int index, T value) {
        if (index < 0 || index >= length) throw new IndexOutOfBoundsException("index out of range");
        data[index] = value;
    }

    @Override
    public String toString() {
        String out = "";
        for (int i = 0; i < length; i++) out += data[i] + " ";
        return out.trim();
    }
}
