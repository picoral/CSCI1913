import java.util.Objects;

public class LinkedList<T> implements List<T> {
    private Node<T> head;
    private Node<T> tail;
    private int length;

    // constructor
    public LinkedList() {
        head = null;
        tail = null;
        length = 0;
    }

    @Override
    public void append(T value) {
        Node<T> nodeToAdd = new Node<>(value);
        if (head == null) {
            head = nodeToAdd;
            tail = nodeToAdd;
        } else {
            tail.setNext(nodeToAdd);
            tail = nodeToAdd;
        }
        length++;
    }

    @Override
    public void prepend(T value) {
        Node<T> nodeToAdd = new Node<>(value);
        if (head == null) {
            head = nodeToAdd;
            tail = nodeToAdd;
        } else {
            nodeToAdd.setNext(head);
            head = nodeToAdd;
        }
        length++;
    }

    @Override
    public int length() { return length; }

    @Override
    public String toString() {
        String out = "";
        Node<T> cur = head;
        while (cur != null) {
            out += cur.getData() + " ";
            cur = cur.getNext();
        }
        return out.trim();
    }

    @Override
    public boolean search(T data) {
        Node<T> currNode = head;
        while (currNode != null) {
            if (Objects.equals(currNode.getData(), data)) {
                return true;
            }
            currNode = currNode.getNext();
        }
        return false;
    }

    // not implemented yet -- stubs so the class compiles
    @Override
    public void insert(int index, T value) {
        throw new UnsupportedOperationException("not implemented yet");
    }

    @Override
    public T get(int index) {
        throw new UnsupportedOperationException("not implemented yet");
    }

    @Override
    public void set(int index, T value) {
        throw new UnsupportedOperationException("not implemented yet");
    }

    @Override
    public T pop(int index) {
        throw new UnsupportedOperationException("not implemented yet");
    }
}
