public class UseLists {
    public static void main(String[] args) {
        List<String> words = new LinkedList<>();
        System.out.println(words.length());
        words.append("apple");
        words.append("banana");
        words.append("kiwi");
        System.out.println(words.length());
        //System.out.println(words.get(1));
        //words.set(0, "pineapple");
        //System.out.println(words.get(0));
        System.out.println(words);
        words.prepend("pear");
        System.out.println(words);
        System.out.println(words.length());
        //words.insert(2, "cat");
        System.out.println(words);
        System.out.println(words.length());
        //System.out.println(words.pop(2));
        System.out.println(words);
        System.out.println(words.length());
    }
}
