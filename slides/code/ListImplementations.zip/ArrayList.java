public class ArrayList<T> implements List<T> {
    private int capacity = 10;
    private int length = 0; // this tells you where the end of the list is
    private T[] data;

    @SuppressWarnings("unchecked")
    public ArrayList() { data = (T[]) new Object[capacity]; }
    public int length() { return length; } // O(1)

    @Override
    public void append(T item) { // big-O? O(n)/n -> O(1)
        if (length == capacity) expandArray();
        data[length] = item;
        length++;
    }

    @Override
    public void set(int index, T value) { // O(1)
        if (index >= 0 && index < length) data[index] = value;
        else throw new IndexOutOfBoundsException("index out of range");
    }

    @Override
    public T get(int index) { // O(1)
        if (index >= 0 && index < length) return data[index];
        else throw new IndexOutOfBoundsException("index out of range");
    }

    public void insert(int index, T value) {
        if (index < 0 || index > length) throw new IndexOutOfBoundsException("index out of range");
        shiftRight(index); // O(n)
        data[index] = value;
    }

    public void prepend(T value) {
        insert(0, value);
    }

    private void shiftRight(int index) { // O(n)
        if (length == capacity) expandArray();
        for (int i=length;i > index;i--) data[i] = data[i-1];
        length++;
    }

    private void shiftLeft(int index) { // O(n)
        for (int i=index;i<length-1;i++) data[i] = data[i+1];
        length--;
        data[length] = null;
    }

    public T pop(int index) { // O(n)
        if (index < 0 || index >= length) throw new IndexOutOfBoundsException("index out of range");
        T out = data[index];
        shiftLeft(index);
        return out;
    }

    public String toString() { // O(n)
        String out = "";
        for (int i=0;i < length;i++) out += data[i] + " ";
        return out.trim();
    }

    @SuppressWarnings("unchecked")
    private void expandArray() { // O(n)
        capacity *= 2;
        T[] newData = (T[]) new Object[capacity];
        for (int i=0;i < length;i++) newData[i] = data[i];
        data = newData;
    }

    public boolean search(T item) { throw new UnsupportedOperationException("not implemented");}



}
