public interface List<T> {
    void append(T value);
    void prepend(T value);
    void insert(int index, T value);
    int length();
    T get(int index);
    void set(int index, T value);
    T pop(int index);
    boolean search(T data);
}
