public class Node<T> {
    private T data;
    private Node<T> next;

    // constructor
    public Node(T data) {
        this.data = data;
        next = null;
    }

    // setters
    public void setNext(Node<T> next) {
        this.next = next;
    }

    public void setData(T data) {
        this.data = data;
    }

    // getters
    public Node<T> getNext() {
        return next;
    }

    public T getData() {
        return data;
    }

}